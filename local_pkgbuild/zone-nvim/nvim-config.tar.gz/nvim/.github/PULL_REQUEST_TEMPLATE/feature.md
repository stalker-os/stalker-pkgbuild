
Fixes Issue # (If it doesn't fix an issue then delete this line)

Features Added:
- Plugin Name (Add links if possible too)

Reasoning:
List why the feature is needed 

Speed (If applicable):
Show the impact on the speed of nvChad

Other:
Anything else relevant goes here
