local s = [[
a
  multiline
    string
]]
