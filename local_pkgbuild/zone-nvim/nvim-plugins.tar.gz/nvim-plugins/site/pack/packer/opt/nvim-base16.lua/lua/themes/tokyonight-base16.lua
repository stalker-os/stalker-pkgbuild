return {
    base0A = "e0af68",
    base04 = "565c64",
    base07 = "c0caf5",
    base05 = "a9b1d6",
    base0E = "9d7cd8",
    base0D = "7aa2f7",
    base0C = "2ac3de",
    base0B = "9ece6a",
    base02 = "3b4261",
    base0F = "db4b4b",
    base03 = "545c7e",
    base08 = "f7768e",
    base01 = "3b4261",
    base00 = "1A1B26",
    base09 = "ff9e64",
    base06 = "bbc5f0"
}
