return {
   base00 = "282828",
   base01 = "3c3836",
   base02 = "504945",
   base03 = "665c54",
   base04 = "bdae93",
   base05 = "d5c4a1",
   base06 = "ebdbb2",
   base07 = "fbf1c7",
   base08 = "b66467",
   base09 = "958793",
   base0A = "dcbb8c",
   base0B = "8d987e",
   base0C = "8aa6a5",
   base0D = "8aa6a5",
   base0E = "b66467",
   base0F = "d3d3c4",
}

