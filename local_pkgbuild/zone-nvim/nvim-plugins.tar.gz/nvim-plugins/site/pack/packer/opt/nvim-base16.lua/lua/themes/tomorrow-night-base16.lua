return {
    base0A = "f0c674",
    base04 = "b4b7b4",
    base07 = "ffffff",
    base05 = "c5c8c6",
    base0E = "b294bb",
    base0D = "81a2be",
    base0C = "8abeb7",
    base0B = "b5bd68",
    base02 = "373b41",
    base0F = "a3685a",
    base03 = "969896",
    base08 = "cc6666",
    base01 = "282a2e",
    base00 = "1d1f21",
    base09 = "de935f",
    base06 = "e0e0e0"
}
