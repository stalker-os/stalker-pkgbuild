return {
    base0A = "EBCB8B",
    base04 = "566074",
    base07 = "ced4df",
    base05 = "bfc5d0",
    base0E = "B48EAD",
    base0D = "81A1C1",
    base0C = "97b7d7",
    base0B = "A3BE8C",
    base02 = "434C5E",
    base0F = "BF616A",
    base03 = "4C566A",
    base08 = "ba5c65",
    base01 = "3B4252",
    base00 = "2E3440",
    base09 = "D08770",
    base06 = "c7cdd8"
}
