return {
    base0A = "f5d595",
    base04 = "4f565d",
    base07 = "b5bcc9",
    base05 = "ced4df",
    base0E = "c2a2e3",
    base0D = "a3b8ef",
    base0C = "abb9e0",
    base0B = "a5d4af",
    base02 = "31383f",
    base0F = "e88e9b",
    base03 = "40474e",
    base08 = "ef8891",
    base01 = "2c333a",
    base00 = "131a21",
    base09 = "EDA685",
    base06 = "d3d9e4"
}
