return {
    base00 = "2a2f38",
    base01 = "323c41",
    base02 = "3a4248",
    base03 = "868d80",
    base04 = "d3c6aa",
    base05 = "e1e3e4",
    base06 = "e1e3e4",
    base07 = "fff9e8",
    base08 = "6dc7e3",
    base09 = "d699b6",
    base0A = "83c092",
    base0B = "eacb64",
    base0C = "ff6578",
    base0D = "9dd274",
    base0E = "f69c5e",
    base0F = "ba9cf3"
}
