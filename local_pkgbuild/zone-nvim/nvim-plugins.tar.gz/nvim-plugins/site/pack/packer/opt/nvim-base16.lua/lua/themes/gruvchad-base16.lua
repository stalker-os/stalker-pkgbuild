return {
    base0A = "e0c080",
    base04 = "d4be98",
    base07 = "c7b89d",
    base05 = "c0b196",
    base0E = "d3869b",
    base0D = "7daea3",
    base0C = "86b17f",
    base0B = "a9b665",
    base02 = "36393a",
    base0F = "d65d0e",
    base03 = "404344",
    base08 = "ec6b64",
    base01 = "2c2f30",
    base00 = "222526",
    base09 = "e78a4e",
    base06 = "c3b499"
}
